import React from "react"
import EFR32Power from "./EFR32BG12P332F1024GL125_Power"

export default function EFR32PowerConnections() {
  return (
    <board width="90mm" height="70mm">
      <EFR32Power name="U1C" schX={40} schY={30} />

      {/* RESETN / BODEN side */}
      <resistor
        name="R1"
        resistance="NR"
        footprint="0402"
        schX={14}
        schY={38}
      />

      {/* VREGVDD decoupling */}
      <capacitor
        name="C2"
        capacitance="10uF"
        footprint="0402"
        schX={14}
        schY={27}
      />
      <capacitor
        name="C3"
        capacitance="1uF"
        footprint="0402"
        schX={20}
        schY={27}
      />

      {/* IOVDD / DVDD side caps */}
      <capacitor
        name="C8"
        capacitance="10uF"
        footprint="0402"
        schX={14}
        schY={13}
      />
      <capacitor
        name="C9"
        capacitance="10nF"
        footprint="0402"
        schX={20}
        schY={13}
      />
      <capacitor
        name="C10"
        capacitance="1uF"
        footprint="0402"
        schX={26}
        schY={13}
      />
      <capacitor
        name="C11"
        capacitance="100nF"
        footprint="0402"
        schX={32}
        schY={13}
      />

      {/* DVDD / DECOUPLE side caps */}
      <capacitor
        name="C1"
        capacitance="100nF"
        footprint="0402"
        schX={66}
        schY={27}
      />
      <capacitor
        name="C5"
        capacitance="1uF"
        footprint="0402"
        schX={66}
        schY={20}
      />

      {/* ----- Left side connections ----- */}

      {/* BODEN tied through R1 to DVDD rail */}
      <trace from=".R1 > .pin2" to=".U1C > .BODEN" />

      {/* VREGVDD to local decoupling network */}
      <trace from=".U1C > .VREGVDD" to=".C2 > .pin1" />
      <trace from=".U1C > .VREGVDD" to=".C3 > .pin1" />

      {/* AVDD to same local supply branch start */}
      <trace from=".U1C > .AVDD" to=".C2 > .pin1" />

      {/* IOVDD pins tied together to DVDD local branch */}
      <trace from=".U1C > .IOVDD_1" to=".C8 > .pin1" />
      <trace from=".U1C > .IOVDD_2" to=".C8 > .pin1" />
      <trace from=".U1C > .IOVDD_3" to=".C8 > .pin1" />
      <trace from=".U1C > .IOVDD_4" to=".C8 > .pin1" />

      <trace from=".C8 > .pin1" to=".C9 > .pin1" />
      <trace from=".C9 > .pin1" to=".C10 > .pin1" />
      <trace from=".C10 > .pin1" to=".C11 > .pin1" />

      {/* ----- Right side connections ----- */}

      {/* DVDD output decoupling */}
      <trace from=".U1C > .DVDD" to=".C1 > .pin1" />

      {/* DECOUPLE pin capacitor */}
      <trace from=".U1C > .DECOUPLE" to=".C5 > .pin1" />

      {/* Grounds from VREGVSS pins to capacitor grounds */}
      <trace from=".U1C > .VREGVSS_1" to=".C1 > .pin2" />
      <trace from=".U1C > .VREGVSS_2" to=".C5 > .pin2" />
      <trace from=".U1C > .VREGVSS_3" to=".C5 > .pin2" />

      {/* Capacitor grounds grouped */}
      <trace from=".C2 > .pin2" to=".C3 > .pin2" />
      <trace from=".C3 > .pin2" to=".C8 > .pin2" />
      <trace from=".C8 > .pin2" to=".C9 > .pin2" />
      <trace from=".C9 > .pin2" to=".C10 > .pin2" />
      <trace from=".C10 > .pin2" to=".C11 > .pin2" />
      <trace from=".C11 > .pin2" to=".C1 > .pin2" />
      <trace from=".C1 > .pin2" to=".C5 > .pin2" />
    </board>
  )
}