import React from "react"
import EFR32Power from "./efr_t2"

export default function EFR32PowerConnections() {
  return (
    <board width="95mm" height="70mm">
      <EFR32Power name="U1C" schX={48} schY={34} />

      <resistor
        name="R1"
        resistance="NR"
        footprint="0402"
        schX={15}
        schY={27}
      />

      <capacitor
        name="C2"
        capacitance="10uF"
        footprint="0402"
        schX={15}
        schY={19}
      />
      <capacitor
        name="C3"
        capacitance="1uF"
        footprint="0402"
        schX={21}
        schY={19}
      />

      <capacitor
        name="C8"
        capacitance="10uF"
        footprint="0402"
        schX={15}
        schY={45}
      />
      <capacitor
        name="C9"
        capacitance="10nF"
        footprint="0402"
        schX={21}
        schY={45}
      />
      <capacitor
        name="C10"
        capacitance="1uF"
        footprint="0402"
        schX={27}
        schY={45}
      />
      <capacitor
        name="C11"
        capacitance="100nF"
        footprint="0402"
        schX={33}
        schY={45}
      />

      <capacitor
        name="C1"
        capacitance="100nF"
        footprint="0402"
        schX={79}
        schY={33}
      />
      <capacitor
        name="C5"
        capacitance="1uF"
        footprint="0402"
        schX={79}
        schY={25}
      />

      <net name="RESETn" />
      <net name="DVDD" isForPower />
      <net name="GND" isGround />
      <net name="SWDIO" />
      <net name="SWCLK" />

      <netlabel net="RESETn" schX={6} schY={25} />
      <netlabel net="DVDD" schX={6} schY={29} />
      <netlabel net="DVDD" schX={6} schY={49} />
      <netlabel net="DVDD" schX={86} schY={10} />
      <netlabel net="SWDIO" schX={86} schY={7} />
      <netlabel net="SWCLK" schX={86} schY={4} />
      <netlabel net="GND" schX={15} schY={13} />
      <netlabel net="GND" schX={15} schY={39} />
      <netlabel net="GND" schX={79} schY={18} />

      {/* RESET */}
      <trace from=".U1C > .RESETN" to="net.RESETn" />

      {/* BODEN pull-up / pull connection */}
      <trace from=".R1 > .pin1" to="net.DVDD" />
      <trace from=".R1 > .pin2" to=".U1C > .BODEN" />

      {/* VREGVDD decoupling */}
      <trace from=".U1C > .VREGVDD" to=".C2 > .pin1" />
      <trace from=".U1C > .VREGVDD" to=".C3 > .pin1" />
      <trace from=".C2 > .pin2" to="net.GND" />
      <trace from=".C3 > .pin2" to="net.GND" />

      {/* AVDD + IOVDD rail */}
      <trace from="net.DVDD" to=".C8 > .pin1" />
      <trace from=".C8 > .pin1" to=".C9 > .pin1" />
      <trace from=".C9 > .pin1" to=".C10 > .pin1" />
      <trace from=".C10 > .pin1" to=".C11 > .pin1" />

      <trace from=".C8 > .pin1" to=".U1C > .AVDD" />
      <trace from=".C8 > .pin1" to=".U1C > .IOVDD_1" />
      <trace from=".C8 > .pin1" to=".U1C > .IOVDD_2" />
      <trace from=".C8 > .pin1" to=".U1C > .IOVDD_3" />
      <trace from=".C8 > .pin1" to=".U1C > .IOVDD_4" />

      <trace from=".C8 > .pin2" to="net.GND" />
      <trace from=".C9 > .pin2" to="net.GND" />
      <trace from=".C10 > .pin2" to="net.GND" />
      <trace from=".C11 > .pin2" to="net.GND" />

      {/* Right side */}
      <trace from=".U1C > .DVDD" to=".C1 > .pin1" />
      <trace from=".U1C > .DECOUPLE" to=".C5 > .pin1" />

      <trace from=".U1C > .VREGVSS_1" to="net.GND" />
      <trace from=".U1C > .VREGVSS_2" to="net.GND" />
      <trace from=".U1C > .VREGVSS_3" to="net.GND" />

      <trace from=".C1 > .pin2" to="net.GND" />
      <trace from=".C5 > .pin2" to="net.GND" />

      {/* Optional labels shown in reference */}
      <trace from="net.DVDD" to="net.SWDIO" />
      <trace from="net.DVDD" to="net.SWCLK" />
    </board>
  )
}