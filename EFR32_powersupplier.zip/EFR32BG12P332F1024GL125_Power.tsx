import React from "react"
import type { ChipProps } from "@tscircuit/props"

/*
  pinLabels must use numeric pin numbers for this template flow.
  The package coordinates like M1 / A10 / B13 are shown as text only.
*/
const pinLabels = {
  RESETN: [1],
  BODEN: [2],
  VREGVDD: [3],
  AVDD: [4],
  IOVDD_1: [5],
  IOVDD_2: [6],
  IOVDD_3: [7],
  IOVDD_4: [8],
  VREGSW: [9],
  DVDD: [10],
  DECOUPLE: [11],
  VREGVSS_1: [12],
  VREGVSS_2: [13],
  VREGVSS_3: [14],
} as const

export default function EFR32PowerChip(
  props: ChipProps<typeof pinLabels>,
) {
  return (
    <chip
      {...props}
      pinLabels={pinLabels}
      symbol={
        <symbol>
          {/* outer body */}
          <schematicrect
            schX={0}
            schY={0}
            width={30}
            height={24}
            isFilled={false}
          />

          {/* title */}
          <schematictext schX={0} schY={11} text="U1C" />
          <schematictext schX={0} schY={-11} text="EFR32BG12P332F1024GL125" />

          {/* left ports */}
          <schematicline x1={-15} y1={9} x2={-19} y2={9} />
          <port name="RESETN" schX={-21} schY={9} direction="left" />
          <schematictext schX={-12} schY={9} text='"M1"' />

          <schematicline x1={-15} y1={7} x2={-19} y2={7} />
          <port name="BODEN" schX={-21} schY={7} direction="left" />
          <schematictext schX={-12} schY={7} text='"L10"' />

          <schematicline x1={-15} y1={4} x2={-19} y2={4} />
          <port name="VREGVDD" schX={-21} schY={4} direction="left" />
          <schematictext schX={-12} schY={4} text='"A11"' />

          <schematicline x1={-15} y1={1} x2={-19} y2={1} />
          <port name="AVDD" schX={-21} schY={1} direction="left" />
          <schematictext schX={-12} schY={1} text='"B13"' />

          <schematicline x1={-15} y1={-2} x2={-19} y2={-2} />
          <port name="IOVDD_1" schX={-21} schY={-2} direction="left" />
          <schematictext schX={-12} schY={-2} text='"M12"' />

          <schematicline x1={-15} y1={-4} x2={-19} y2={-4} />
          <port name="IOVDD_2" schX={-21} schY={-4} direction="left" />
          <schematictext schX={-12} schY={-4} text='"B10"' />

          <schematicline x1={-15} y1={-6} x2={-19} y2={-6} />
          <port name="IOVDD_3" schX={-21} schY={-6} direction="left" />
          <schematictext schX={-12} schY={-6} text='"F2"' />

          <schematicline x1={-15} y1={-8} x2={-19} y2={-8} />
          <port name="IOVDD_4" schX={-21} schY={-8} direction="left" />
          <schematictext schX={-12} schY={-8} text='"F11"' />

          {/* right ports */}
          <schematicline x1={15} y1={7} x2={19} y2={7} />
          <port name="VREGSW" schX={21} schY={7} direction="right" />
          <schematictext schX={12} schY={7} text='"A12"' />

          <schematicline x1={15} y1={4} x2={19} y2={4} />
          <port name="DVDD" schX={21} schY={4} direction="right" />
          <schematictext schX={12} schY={4} text='"A10"' />

          <schematicline x1={15} y1={1} x2={19} y2={1} />
          <port name="DECOUPLE" schX={21} schY={1} direction="right" />
          <schematictext schX={12} schY={1} text='"A9"' />

          <schematicline x1={15} y1={-4} x2={19} y2={-4} />
          <port name="VREGVSS_1" schX={21} schY={-4} direction="right" />
          <schematictext schX={12} schY={-4} text='"A13"' />

          <schematicline x1={15} y1={-6} x2={19} y2={-6} />
          <port name="VREGVSS_2" schX={21} schY={-6} direction="right" />
          <schematictext schX={12} schY={-6} text='"B11"' />

          <schematicline x1={15} y1={-8} x2={19} y2={-8} />
          <port name="VREGVSS_3" schX={21} schY={-8} direction="right" />
          <schematictext schX={12} schY={-8} text='"B12"' />

          {/* internal labels */}
          <schematictext schX={-5} schY={8} text="'RESET'" />
          <schematictext schX={8} schY={8} text="'DC/DC'" />
          <schematictext schX={-5} schY={4} text="'DIGITAL SUPPLY'" />
          <schematictext schX={-5} schY={1} text="'ANALOG SUPPLY'" />
          <schematictext schX={-5} schY={-3} text="'I/O SUPPLY'" />
          <schematictext schX={8} schY={4} text="'DVDD'" />
          <schematictext schX={8} schY={1} text="'DECOUPLE'" />
          <schematictext schX={8} schY={-6} text="'GND'" />
        </symbol>
      }
    />
  )
}