import React from "react"
import type { ChipProps } from "@tscircuit/props"

const pinLabels = {
  pin1: "RESETN",
  pin2: "BODEN",
  pin3: "VREGVDD",
  pin4: "AVDD",
  pin5: "IOVDD_1",
  pin6: "IOVDD_2",
  pin7: "IOVDD_3",
  pin8: "IOVDD_4",
  pin9: "VREGSW",
  pin10: "DVDD",
  pin11: "DECOUPLE",
  pin12: "VREGVSS_1",
  pin13: "VREGVSS_2",
  pin14: "VREGVSS_3",
} as const

export default function EFR32Power(
  props: ChipProps<typeof pinLabels>,
) {
  return (
    <chip
      {...props}
      pinLabels={pinLabels}
      doNotPlace
      schWidth={30}
      schHeight={24}
      schPinArrangement={{
        leftSide: {
          direction: "top-to-bottom",
          pins: [
            "RESETN",
            "BODEN",
            "VREGVDD",
            "AVDD",
            "IOVDD_1",
            "IOVDD_2",
            "IOVDD_3",
            "IOVDD_4",
          ],
        },
        rightSide: {
          direction: "top-to-bottom",
          pins: [
            "VREGSW",
            "DVDD",
            "DECOUPLE",
            "VREGVSS_1",
            "VREGVSS_2",
            "VREGVSS_3",
          ],
        },
      }}
      symbol={
        <symbol>
          <schematicrect
            schX={0}
            schY={0}
            width={30}
            height={24}
            isFilled={false}
          />

          {/* real connection ports */}
          <port name="RESETN" schX={-15} schY={9} />
          <port name="BODEN" schX={-15} schY={7} />
          <port name="VREGVDD" schX={-15} schY={4} />
          <port name="AVDD" schX={-15} schY={1} />
          <port name="IOVDD_1" schX={-15} schY={-2} />
          <port name="IOVDD_2" schX={-15} schY={-4} />
          <port name="IOVDD_3" schX={-15} schY={-6} />
          <port name="IOVDD_4" schX={-15} schY={-8} />

          <port name="VREGSW" schX={15} schY={7} />
          <port name="DVDD" schX={15} schY={4} />
          <port name="DECOUPLE" schX={15} schY={1} />
          <port name="VREGVSS_1" schX={15} schY={-4} />
          <port name="VREGVSS_2" schX={15} schY={-6} />
          <port name="VREGVSS_3" schX={15} schY={-8} />

          {/* title */}
          <schematictext schX={0} schY={11} text="U1C" />
          <schematictext schX={0} schY={-11} text="EFR32BG12P332F1024GL125" />

          {/* left package-ball text */}
          <schematictext schX={-12} schY={9} text="M1" />
          <schematictext schX={-12} schY={7} text="L10" />
          <schematictext schX={-12} schY={4} text="A11" />
          <schematictext schX={-12} schY={1} text="B13" />
          <schematictext schX={-12} schY={-2} text="M12" />
          <schematictext schX={-12} schY={-4} text="B10" />
          <schematictext schX={-12} schY={-6} text="F2" />
          <schematictext schX={-12} schY={-8} text="F11" />

          {/* right package-ball text */}
          <schematictext schX={12} schY={7} text="A12" />
          <schematictext schX={12} schY={4} text="A10" />
          <schematictext schX={12} schY={1} text="A9" />
          <schematictext schX={12} schY={-4} text="A13" />
          <schematictext schX={12} schY={-6} text="B11" />
          <schematictext schX={12} schY={-8} text="B12" />

          {/* internal section labels */}
          <schematictext schX={-3} schY={9} text="Reset" />
          <schematictext schX={-2} schY={4} text="Digital Supply" />
          <schematictext schX={-2} schY={1} text="Analog Supply" />
          <schematictext schX={-2} schY={-4} text="I/O Supply" />
          <schematictext schX={7} schY={8} text="DC/DC Regulator" />
          <schematictext schX={8} schY={4} text="DVDD" />
          <schematictext schX={6} schY={1} text="DECOUPLE" />
          <schematictext schX={8} schY={-6} text="Ground" />
        </symbol>
      }
    />
  )
}